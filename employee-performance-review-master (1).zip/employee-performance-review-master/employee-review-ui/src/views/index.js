import AdminView from "./AdminView";
import HomeView from "./HomeView";
import AllReviewsView from "./AllReviewsView";
import LoginView from "./LoginView";

export { AdminView, HomeView, AllReviewsView, LoginView };
