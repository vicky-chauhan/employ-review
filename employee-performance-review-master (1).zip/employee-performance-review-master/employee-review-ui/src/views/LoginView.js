import React from "react";
import "./../App.css";

import { LoginForm } from "../containers";

function LoginView() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}

export default LoginView;
